HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Linux; U; Android 5.1; en-US; SHIELD Android TV Build/LMY47D) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/10.5.2.582 U3/0.8.0 Mobile Safari/534.30',
    'authority': 'looktv.mn',
    'origin': 'https://looktv.mn',
    'x-device-uid': '5c9769d2-d3c8-4df0-abc9-a2ac2e2e9ee0',
    'x-geo-hash': 'unknown',
    'Accept-Encoding': 'gzip, deflate, br'
}

LIC_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Linux; U; Android 5.1; en-US; SHIELD Android TV Build/LMY47D) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/10.5.2.582 U3/0.8.0 Mobile Safari/534.30',
    'Host': 'lic.drmtoday.com',
    'Origin': 'https://looktv.mn',
    'Referer': 'https://looktv.mn',
    'Sec-Fetch-Dest' : 'empty',
    'Sec-Fetch-Mode' : 'cors',
    'Sec-Fetch-Site' : 'cross-site'
}

LICENSE_URL        = 'https://lic.drmtoday.com/license-proxy-widevine/cenc/'
PROFILE_URL        = 'https://looktv.mn/api/wbe/v2/consumer/subscribers/{}/profiles'
MD5_KEY            = '35a131404c264f36ca4031500143e4acf0682cd5'
LOGIN_URL          = 'https://looktv.mn/api/idm/v1/consumer/login/email'
TOKEN_URL          = 'https://looktv.mn/api/hydra/v1/oauth2/token'
LIVE_URL           = 'https://looktv.mn/api/wbe/v2/consumer/whatson'
PLAYBACK_URL       = 'https://looktv.mn/api/wbe/v2/consumer/channels/{}/programs'
RECORD_URL         = 'https://looktv.mn/api/wbe/v2/consumer/channels/{}/programs/{}/recording'

DEV_TYPE           = 'androidtv'
SERVICE_TIME       = 300
