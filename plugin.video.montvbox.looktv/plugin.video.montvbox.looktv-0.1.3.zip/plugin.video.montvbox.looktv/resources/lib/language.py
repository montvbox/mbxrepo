from slyguy.language import BaseLanguage

class Language(BaseLanguage):
    ASK_USERNAME     = 30001
    ASK_PASSWORD     = 30002
    LOGIN_ERROR      = 30003
    PLAYBACK_ERROR   = 30004
    LIVE             = 30005
    PLAYED           = 30006
    URJIGDAR_TSAAD   = 30007
    URJIGDAR         = 30008
    OCHIGDOR         = 30009
    ONOODOR         = 30010
    MARGAASH         = 30011
    NOGOODOR         = 30012
    DAY_FORMAT       = 30014

    NO_MATCHES       = 30012
    DATE_FORMAT      = 30013
    MATCH_PLOT       = 30014
    PROGRAM_PLOT     = 30015

    MULTIPART_VIDEO  = 30016
    PLAYBACK_SOURCE  = 30017

    SUBSCRIBE_ERROR  = 30020
    NO_VIDEOS        = 30021

    FUTURE_PROGRAM   = 30022

_ = Language()
