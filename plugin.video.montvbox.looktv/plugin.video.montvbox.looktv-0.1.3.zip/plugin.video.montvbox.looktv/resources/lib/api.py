from time import time
import arrow

from slyguy import userdata
from slyguy.util import jwt_data
from slyguy.log import log
from slyguy.session import Session
from slyguy.exceptions import Error
from slyguy.mem_cache import cached

from .constants import HEADERS, TOKEN_URL, RECORD_URL, LOGIN_URL, PLAYBACK_URL, LIVE_URL
from .language import _

class APIError(Error):
    pass

class API(object):
    def new_session(self):
        self.logged_in = False
        self._session  = Session(HEADERS)
        self._set_authentication()

    def _set_authentication(self):
        token = userdata.get('access_token')
        if not token:
            return

        self._session.headers.update({'Authorization': 'Bearer {}'.format(token)})
        self.logged_in = True

    def _refresh_token(self, force=False):
        refresh_token = userdata.get('refresh_token')
        if not refresh_token or (not force and userdata.get('expires', 0) > time()):
            return

        payload = {
            'grant_type': 'refresh_token',
            'refresh_token': refresh_token,
            'client_id': 'public-client'
        }

        data = self._session.post(TOKEN_URL, data=payload).json()
        if 'error' in data:
            self.logout()
            raise APIError(data['error']['message'])

        userdata.set('access_token', data['access_token'])
        userdata.set('refresh_token', data['refresh_token'])
        userdata.set('expires', int(time()) + int(data['expires_in']) - 30)
        self._set_authentication()

    def login(self, username, password):
        self.logout()

        data = {
            'identifier': username,
            'password': password,
            'deviceId': '5c9769d2-d3c8-4df0-abc9-a2ac2e2e9ee0',
            'deviceName':'Chrome 91.0.4472.114',
            'deviceType':'WEB_BROWSER_CAPABLE_DEVICE'
        }

        r = self._session.post(LOGIN_URL, json=data)
        try:
            data = r.json()
        except:
            raise APIError(_(_.LOGIN_ERROR, msg=r.status_code))

        access_token = data.get('access_token')
        if not access_token:
            raise APIError(_(_.LOGIN_ERROR, msg=data.get('detail', '')))

        token_data = jwt_data(access_token)
        userdata.set('access_token', access_token)
        userdata.set('refresh_token', data['refresh_token'])
        userdata.set('expires', int(time()) + int(data['expires_in']) - 30)
        userdata.set('userid', token_data['ext']['userId'])
        userdata.set('regionid', int(token_data['ext']['regionIds'][0]))
        self._set_authentication()

    def live_matches(self):
        self._refresh_token()
        params = {
            'isodate'     : arrow.utcnow().isoformat(),
            'time-window' : 240
        }
        return self._session.get(LIVE_URL, params=params).json()

    def programm(self, chanid, day_count):
        self._refresh_token()
        t = arrow.utcnow().shift(days=int(day_count))
        params = {
            'isodate'    : t.isoformat()
        }
        return self._session.get(PLAYBACK_URL.format(chanid), params=params).json()

    def get_record_url(self, chan_id, rec_id):
        self._refresh_token()
        return self._session.get(RECORD_URL.format(chan_id, rec_id)).json()

    def get_location(self, url):
        self._refresh_token()
        resp = self._session.get(url, allow_redirects=False)
        return resp.headers['location']

    def logout(self):
        userdata.delete('access_token')
        userdata.delete('refresh_token')
        userdata.delete('expires')
        self.new_session()
