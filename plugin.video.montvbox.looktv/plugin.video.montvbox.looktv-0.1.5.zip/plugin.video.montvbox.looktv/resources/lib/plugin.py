import datetime
import json
from base64 import b64encode

from kodi_six import xbmc, xbmcaddon
import arrow
from slyguy import gui, inputstream, plugin, settings, signals, userdata
from slyguy.util import get_addon

from .api import API
from .constants import (LIC_HEADERS, LICENSE_URL )
from .language import _

api = API()

@signals.on(signals.BEFORE_DISPATCH)
def before_dispatch():
    api.new_session()

    username = settings.get('username')
    if not username:
        addon = get_addon('script.video.montvbox-looktv', install=False)
        if not addon:
            return
        username = addon.getSetting('username')
        password = addon.getSetting('password')
        settings.set('username', username)
        settings.set('password', password)

    username = settings.get('username')
    password = settings.get('password')

    api.login(username, password)
    plugin.logged_in = api.logged_in

@plugin.route('')
def home(**kwargs):
    folder = plugin.Folder()

    folder.add_item(label=_(_.LIVE, _bold=True), path=plugin.url_for(live))
    folder.add_item(label=_(_.PLAYED, _bold=True), path=plugin.url_for(played))

    return folder

@plugin.route()
def live(**kwargs):
    folder = plugin.Folder(_.LIVE, no_items_label=_.NO_MATCHES)

    data = api.live_matches()
    for row in data['data']['channels']:
        if row['purchaseInfo']['status'] != 'free':
            continue

        title = 'No program'
        start = ''
        end = ''

        if len(row['programs']) > 0:
            title = row['programs'][0]['title']
            start = arrow.get(row['programs'][0]['start']).to('local').format('h:mma')
            end = arrow.get(row['programs'][0]['end']).to('local').format('h:mma')

        info = {'plot': _(_.PROGRAM_PLOT, title=title, start=start, end=end)}
        item = plugin.Item(
            label    = row['name'],
            info     = info,
            art      = {'thumb': row['icon']},
            path     = plugin.url_for(play_live, url=row['streams'][0]['src'] ),
            playable = True,
        )

        folder.add_items(item)

    return folder

@plugin.route()
def played(**kwargs):
    folder = plugin.Folder(_.PLAYED, no_items_label=_.NO_MATCHES)

    data = api.live_matches()
    for row in data['data']['channels']:
        title = 'No program'
        if len(row['programs']) > 0:
            title = row['programs'][0]['title']

        item = plugin.Item(
            label    = row['name'],
            art      = {'thumb': row['icon']},
            path     = plugin.url_for(tv_programm, chanid=row['id'], icon=row['icon']),
            playable = False,
        )

        folder.add_items(item)

    return folder

@plugin.route()
def tv_programm(chanid, icon, **kwargs):
    folder = plugin.Folder()
    t = arrow.utcnow()
    t1 = t.shift(days=-3).format(_.DAY_FORMAT)
    t2 = t.shift(days=-2).format(_.DAY_FORMAT)
    t3 = t.shift(days=-1).format(_.DAY_FORMAT)
    t4 = t.format(_.DAY_FORMAT)
    t5 = t.shift(days=+1).format(_.DAY_FORMAT)
    t6 = t.shift(days=+2).format(_.DAY_FORMAT)
    folder.add_item(label=_.URJIGDAR_TSAAD, info={'plot': t1}, art={'thumb': icon}, path=plugin.url_for(tv_programm_on, chanid=chanid,  label_date = t1, count_date = -3))
    folder.add_item(label=_.URJIGDAR, info={'plot': t2}, art={'thumb': icon}, path=plugin.url_for(tv_programm_on, chanid=chanid,  label_date = t2, count_date = -2))
    folder.add_item(label=_.OCHIGDOR, info={'plot': t3}, art={'thumb': icon}, path=plugin.url_for(tv_programm_on, chanid=chanid,  label_date = t3, count_date = -1))
    folder.add_item(label=_.ONOODOR, info={'plot': t4}, art={'thumb': icon}, path=plugin.url_for(tv_programm_on, chanid=chanid,  label_date = t4, count_date = 0))
    folder.add_item(label=_.MARGAASH, info={'plot': t5}, art={'thumb': icon}, path=plugin.url_for(tv_programm_on, chanid=chanid,  label_date = t5, count_date = 1))
    folder.add_item(label=_.NOGOODOR, info={'plot': t6}, art={'thumb': icon}, path=plugin.url_for(tv_programm_on, chanid=chanid,  label_date = t6, count_date = 2))
    return folder

@plugin.route()
def tv_programm_on(chanid, label_date, count_date, **kwargs):
    folder = plugin.Folder(label_date)
    data = api.programm(chanid, count_date)
    for row in data['data']:
        start = arrow.get(row['start']).to('local').format('h:mma')
        start_time = arrow.get(row['start']).to('utc')

        end = arrow.get(row['end']).to('local').format('h:mma')
        title = row['title']
        info = {'plot': _(_.PROGRAM_PLOT, title=title, start=start, end=end)}

        item = plugin.Item(
            label = title,
            info = info,
            playable = True,
            path = plugin.url_for(play_record, chan_id=chanid, rec_id=row['id'], start_time=start_time)
        )
        folder.add_items(item)

    return folder

@plugin.route()
def play_record(chan_id, rec_id, start_time, **kwargs):

    now = arrow.now()
    start = arrow.get(start_time).to('utc')
    if start > now:
        gui.ok(_.FUTURE_PROGRAM)
        return

    rec_url = api.get_record_url(chan_id, rec_id)
    src = ''

    for stream in rec_url['data'][0]['streams']:
        if stream['protocolStack'] == 'mpd':
            src = stream['src']
    new_url = api.get_location(src)
    return _play(new_url, live=True)

@plugin.route()
def play_live(url, **kwargs):
    new_url = api.get_location(url)
    return _play(new_url, live=True)

def _play(url, live=False):
    dt_custom_data = {
        'userId': userdata.get('userid'),
        'sessionId': userdata.get('userid'),
        'merchant': 'beenius_univision'
    }
    custom_data = b64encode(json.dumps(dt_custom_data).encode('utf-8')).decode('utf-8')
    headers = LIC_HEADERS.copy()
    headers['dt-custom-data'] = custom_data
    return plugin.Item(
        path = url,
        headers = headers,
        inputstream = inputstream.Widevine(license_key=LICENSE_URL, response='JBlicense')
    )
