from time import time
import arrow
import json
import uuid

from slyguy import userdata, settings
from slyguy.util import jwt_data
from slyguy.util import strip_namespaces, hash_6, get_system_arch
from slyguy.log import log
from slyguy.session import Session
from slyguy.exceptions import Error
from slyguy.mem_cache import cached

from .constants import HEADERS, TOKEN_URL, RECORD_URL, LOGIN_URL, PLAYBACK_URL, LIVE_URL, PROFILE_URL
from .language import _

class APIError(Error):
    pass

class API(object):
    def new_session(self):
        self.logged_in = False
        self._session  = Session(HEADERS)
        self._set_authentication()

    def _set_authentication(self):
        token = userdata.get('access_token')
        if not token:
            return

        self._session.headers.update({'Authorization': 'Bearer {}'.format(token)})
        self.logged_in = True

    def _refresh_token(self, force=False):
        refresh_token = userdata.get('refresh_token')
        if not refresh_token or (not force and userdata.get('expires', 0) > time()):
            return

        payload = {
            'grant_type': 'refresh_token',
            'refresh_token': refresh_token,
            'client_id': 'public-client'
        }

        data = self._session.post(TOKEN_URL, data=payload).json()
        if 'error' in data:
            self.logout()
            raise APIError(data['error']['message'])

        userdata.set('access_token', data['access_token'])
        userdata.set('refresh_token', data['refresh_token'])
        userdata.set('expires', int(time()) + int(data['expires_in']) - 30)
        self._set_authentication()

    def _device_id(self):
        device_id = userdata.get('device_id')
        if device_id:
            return device_id

        device_id = settings.get('device_id')

        try:
            mac_address = uuid.getnode()
            if mac_address != uuid.getnode():
                mac_address = ''
        except:
            mac_address = ''

        system, arch = get_system_arch()
        device_id = device_id.format(username=userdata.get('username'), mac_address=mac_address, system=system).strip()

        if not device_id:
            device_id = uuid.uuid4()

        log.debug('Raw device id: {}'.format(device_id))
        #device_id = hash_6(device_id, length=16)
        #log.debug('Hashed device id: {}'.format(device_id))

        userdata.set('device_id', '{}'.format(device_id))
        return '{}'.format(device_id)

    def login(self, username, password):
        self.logout()

        data = {
            'identifier': username,
            'password': password,
            'deviceId': self._device_id(),
            'deviceName':'Chrome 91.0.4472.114',
            'deviceType':'WEB_BROWSER_CAPABLE_DEVICE'
        }
        log.info('device_id: {}'.format(self._device_id()))
        # 'deviceId': '5c9769d2-d3c8-4df0-abc9-a2ac2e2e9ee0',
        r = self._session.post(LOGIN_URL, json=data)
        try:
            data = r.json()
        except:
            raise APIError(_(_.LOGIN_ERROR, msg=r.status_code))

        access_token = data.get('access_token')
        if not access_token:
            raise APIError(_(_.LOGIN_ERROR, msg=data.get('detail', '')))

        token_data = jwt_data(access_token)
        log.info('token_data: {}'.format(json.dumps(token_data)))
        userdata.set('access_token', access_token)
        userdata.set('refresh_token', data['refresh_token'])
        userdata.set('expires', int(time()) + int(data['expires_in']) - 30)
        userdata.set('userid', token_data['ext']['userId'])
        userdata.set('regionid', int(token_data['ext']['regionIds'][0]))

        self._session.headers.update({'authorization': 'Bearer {}'.format(access_token)})
        self._session.headers.update({'referer': 'https://looktv.mn/home'})
        self._session.headers.update({'beenius-profile-id': '0'})
        self._session.headers.update({'accept-encoding': 'gzip, deflate, br'})
        self._session.headers.update({'beenius-device-uid': self._device_id()})
        self._session.headers.update({'beenius-device-uuid': self._device_id()})
        self._session.headers.update({'beenius-geo-hash': '9c955ca7ac00b9aa8f009608bce499e8'})

        self._session.headers.update({'beenius-profile-id': '0'})
        self._session.headers.update({'beenius-profile-uid': ''})
        self._session.headers.update({'beenius-region-id': '{}'.format(userdata.get('regionid'))})
        self._session.headers.update({'beenius-subscriber-id': '{}'.format(userdata.get('userid'))})
        self._session.headers.update({   'Sec-Fetch-Dest' : 'empty'})
        self._session.headers.update({   'Sec-Fetch-Mode' : 'cors'})
        self._session.headers.update({   'Sec-Fetch-Site' : 'same-origin'})
        self._session.headers.update({   'sec-ch-ua-mobile' : '?0'})
        self._session.headers.update({   'accept' : 'application/vnd.beenius+json'})
        self._session.headers.update({   'accept-language' : 'en-US,en;q=0.9' })
        self._session.headers.update({   'sec-ch-ua' : '"Chromium";v="92", " Not A;Brand";v="99", "Google Chrome";v="92"' })
        self._session.headers.update({   'user-agent' : 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.82 Safari/537.36' })

        r1 = self._session.get(PROFILE_URL.format(userdata.get('userid')))
        try:
            log.info('r1 response: {}'.format(json.dumps(r1.json())))
            rdata = r1.json()
        except:
            raise APIError(_(_.LOGIN_ERROR, msg=r1.status_code))

        log.info('rdata: {}'.format(json.dumps(rdata)))
        userdata.set('userid1', rdata['data'][0]['id'])
        userdata.set('uid', rdata['data'][0]['uid'])
        self._session.headers.update({'beenius-profile-id': '{}'.format(userdata.get('userid1'))})
        self._session.headers.update({'beenius-profile-uid': '{}'.format(userdata.get('uid'))})
        self._session.headers.update({'beenius-region-id': '{}'.format(userdata.get('regionid'))})
        self._session.headers.update({'beenius-subscriber-id': '{}'.format(userdata.get('userid'))})

        self._set_authentication()

    def live_matches(self):
        self._refresh_token()
        params = {
            'isodate'     : arrow.utcnow().isoformat(),
            'time-window' : 240
        }

        return self._session.get(LIVE_URL, params=params).json()

    def programm(self, chanid, day_count):
        self._refresh_token()
        t = arrow.utcnow().shift(days=int(day_count))
        params = {
            'isodate'    : t.isoformat()
        }

        return self._session.get(PLAYBACK_URL.format(chanid), params=params).json()

    def get_record_url(self, chan_id, rec_id):
        self._refresh_token()
        return self._session.get(RECORD_URL.format(chan_id, rec_id)).json()

    def get_location(self, url):
        self._refresh_token()
        resp = self._session.get(url, allow_redirects=False)
        return resp.headers['location']

    def logout(self):
        userdata.delete('access_token')
        userdata.delete('refresh_token')
        userdata.delete('expires')
        userdata.delete('userid')
        userdata.delete('regionid')
        userdata.delete('userid1')
        userdata.delete('uid')
        self.new_session()
