# coding: utf-8
""" Main Gui Module """

import urllib2
import urllib
import sys
import json
import os.path
import datetime
import base64
import ssl
import xbmc
import xbmcaddon
import xbmcgui
# from simplecache import  SimpleCache
# import inputstreamhelper

import const

# import threading
reload(sys)
sys.setdefaultencoding('UTF8')
WIDTH = 1280
HEIGHT = 720

dialog = xbmcgui.Dialog()

# Before update added this line just for fun
def log(text):
    xbmc.log('%s addon: ############# %s' % (const.ADDON_NAME, text))


addon = xbmcaddon.Addon()


def cleanUpUrl(url):
    """ just stop error """
    return url


def num(a):
    if a is None:
        return
    n = int(float(a))
    return n


def _json_rpc_request(payload):
    response = xbmc.executeJSONRPC(json.dumps(payload))
    return json.loads(response)


def _has_inputstream():
    """Checks if selected InputStream add-on is installed."""
    payload = {
        'jsonrpc': '2.0',
        'id': 1,
        'method': 'Addons.GetAddonDetails',
        'params': {
            'addonid': 'inputstream.adaptive'
        }
    }
    data = _json_rpc_request(payload)

    if 'error' in data:
        try:
            xbmc.executebuiltin('InstallAddon(inputstream.adaptive)', True)
            xbmc.executeJSONRPC(('{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled",'
                                 '"params":{"addonid":"inputstream.adaptive","enabled":true}}'))
            return xbmcaddon.Addon('inputstream.adaptive')
        except Exception as e:
            log(e)
            xbmcgui.Dialog().ok('Missing inputstream.adaptive add-on',
                                ('inputstream.adaptive add-on not found or not enabled.'
                                 'This add-on is required to view DRM protected content.'))
        return False
    else:
        return True


def startBusy():
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")


def stopBusy():
    xbmc.executebuiltin("Dialog.Close(busydialognocancel)")


# #######################################################################
# ##                            Controller                             ##
# #######################################################################


class Controller(object):
    menu_list = list()
    list_instance = None
    last_sel_item = None
    last_sel_on_list = 0
    loading = False
    player = None
    platformId = None
    timezone = 'Europe/Berlin'

    def onInit(self):
        pass

    def changeControlVisibility(self, _self, _bool, controlId, **data):
        loader = _self.getControl(controlId)
        loader.setVisible(_bool)

        if 'focusId' in data:
            focusId = data['focusId']
            _self.setFocus(_self.getControl(focusId))

    def getToken(self):
        # self.login.logOut()
        # token = self.login.logIN()
        # log('Got token: ' + token)
        return self.login.token

    # def getToken(self):
    #     token = None

    #     if os.path.isfile(const.TOKEN_FILEPATH):
    #         fopen = open(const.TOKEN_FILEPATH, "r")
    #         temp_token = fopen.read()
    #         fopen.close()
    #         if temp_token:
    #             arr = temp_token.partition(" ")
    #             token = arr[0]
    #             if arr[2] and arr[2] != const.ADDON.getSetting('username'):
    #                 token = ''
    #             temp_token = ''

    #     if not token:
    #         return
    #     return token

    def getListData(self, url, data=None, is_menu=None):

        if (not const.ADDON.getSetting('username')) or (not const.ADDON.getSetting('password')):
            dialog.ok(const.LANG(32003), const.LANG(32005))
            const.ADDON.openSettings(const.ID)
            login = self.login.logIN()

        # cached = const.CACHE.get(
        #     str(url + '_' + const.ADDON.getSetting('username') + '_' +
        #         const.ADDON.getSetting('password')))

        cached = None  # Just set None because no cache used
        token = self.getToken()

        if cached is not None and is_menu is None:
            return cached
        else:
            url = const.SITE_PATH + url
            token = self.getToken()

            if not token:
                ans = dialog.yesno(const.LANG(32003),
                                   'За да използвате услугата трябва да се впишете ')

                if ans:
                    login = self.login.logIN()
                    if not login:
                        const.ADDON.openSettings(const.ID)
                        login = self.login.logIN()
                        token = self.getToken()
                        if not login:
                            xbmc.executebuiltin("ActivateWindow(Home)")
                            return
                else:
                    return

            send = ({'token': token})
            if data is not None:
                send.update(data)

            data = self.getData(url, data=send)

        expiration = datetime.timedelta(hours=3)
        cleaned_url = cleanUpUrl(url)

        if const.LIVETV_PATH in cleaned_url and len(cleaned_url) > len(const.LIVETV_PATH):
            expiration = datetime.timedelta(minutes=15)

        # const.CACHE.set(str(url + '_' + const.ADDON.getSetting('username') + '_' +
        #                     const.ADDON.getSetting('password')),
        #                 data,
        #                 expiration=expiration)
        return data

    def stopPlayer(self):
        if self.player and self.player.is_playing:
            self.player.stopPlayer()

    def logIn(self):
        usr = const.ADDON.getSetting('username')
        pas = const.ADDON.getSetting('password')

        data = self.makeUserPass(usr, pas)
        self.token = self.getData(const.SITE_LOGIN_PAGE, data)
        log("Token => " + self.token)
        return self.token

    def logOut(self):
        try:
            r = self.getData(const.SITE_LOGOUT_PAGE, None)
            log(r)
        except Exception as e:
            log('error on logout')
            log(e)

    def makeUserPass(self, usr, pas):
        return {
            "email": usr,
            "password": base64.b64encode(pas),
            "platformId": const.PLATFORM_ID,
            "deviceId": "W",
            "deviceType": "W",
            "authInstitude": "0",
            "accessNetworkType": "W",
            "deviceModel": "PC"
        }

    def tvPlay(self, url, title):
        startBusy()
        # url = "https://devstreaming-cdn.apple.com/videos/streaming/examples/img_bipbop_adv_example_ts/master.m3u8"
        if self.player:
            self.player.stopPlayer()

        log('self.player was Not there, creating new one')
        self.player = Player()
        self.player.is_playing = True
        # url = "https://cdn.looktv.mn/2c9f807e51955cea0151a5f6a83200ab/origin_1/channel/mnb.smil/playlist.m3u8"
        log("Playing : " + url)
        # token = self.getToken()
        # self.logOut()
        token = self.logIn()
        urlContLang = url + (
            '|Content-Language='
            'EFj%2BLwlssRbtd2PTw8224DM8APdJCkSPJVA5%2B7sUEaVLzwde3z62mJC2e7WvfPtt')
        urlUserAgent = urlContLang + ('&User-Agent=Mozilla/5.0%20(Windows%20NT%206.1;%20rv:25.0)'
                                      '%20Gecko/20100101%20Firefox/25.0')
        urlCookie = urlUserAgent + '&Cookie=JSESSIONID=' + token

        self.player.tracking_key = ''
        # self.player.is_live  = self.isLive(url, info['tracking_key']);

        # self.player.resume = 0
        url = urlCookie
        log("Playing : " + url)
        # is_helper = inputstreamhelper.Helper("hls", drm=None)
        # if is_helper.check_inputstream():
        #   playitem = xbmcgui.ListItem(path=url)
        #   playitem.setProperty('inputstreamaddon', is_helper.inputstream_addon)
        #   playitem.setProperty('inputstream.adaptive.manifest_type', "hls")
        #   #playitem.setProperty('inputstream.adaptive.license_type', DRM)
        #   #playitem.setProperty('inputstream.adaptive.license_key', LICENSE_URL + '||R{SSM}|')
        #   xbmc.Player().play(item=url, listitem=playitem)
        # if _has_inputstream():
        #   li = xbmcgui.ListItem(label=title)
        #   li.setProperty('inputstreamaddon', 'inputstream.adaptive')
        #   li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        #   self.player.play(url, li)
        #   xbmc.sleep(500)
        # #
        stopBusy()

        # if not self.player.isPlaying():
        self.player.play(url, xbmcgui.ListItem(label=title))

    def writeInLiveFile(self, url):
        fopen = open(const.STRM_FILEPATH, "w+")
        fopen.write(url)
        fopen.close()

    def createMenu(self):
        list_items = list()

        menulist = list()
        menulist.append({'title': 'Профил', 'key': 'account'})
        menulist.append({'title': 'Търсене', 'key': 'search'})
        menulist.append({'title': 'изход', 'key': 'logout'})

        for (key, val) in enumerate(menulist):
            label = val['title'].encode('utf-8')

            item = xbmcgui.ListItem(u"{0}".format(label), label2=u"{0}".format(val['key']))
            list_items.append(item)
        self.menu_list = list_items

    def renderMenu(self, _self):
        if not self.menu_list:
            self.getChannelList()
        self.list_instance = List()
        self.removeMenu()
        self.list_instance.doModal()

    def removeMenu(self):
        if self.list_instance:
            self.list_instance.close()

    def getData(self, url, data):
        if data:
            send = urllib.urlencode(data)
            self.request = urllib2.Request(url, send)
        else:
            self.request = urllib2.Request(url)
        token = self.login.token
        if token:
            self.request.add_header('Cookie', 'JSESSIONID=' + token)
        self.request.add_header(
            'User-Agent', 'Mozilla/5.0 (Windows NT 6.1; rv:25.0) Gecko/20100101 Firefox/25.0')
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        try:
            response = urllib2.urlopen(self.request, context=ctx)

        except urllib2.HTTPError as e:
            dialog.ok(const.LANG(32003), "ERROR")
            log(e)
            return
        except urllib2.URLError as e:
            dialog.ok(const.LANG(32003), const.LANG(32007))
            log(e)
            return

        data_result = response.read()
        xbmc.log('%s addon: %s' % (const.ADDON_NAME, url))

        try:
            res = json.loads(data_result)
        except Exception as e:
            xbmc.log('%s addon: %s' % (const.ADDON_NAME, e))
            return

        # if 'resultCode' in res:
        #   if res['resultCode'] == 305:
        #       ans = dialog.yesno(const.LANG(32212), const.LANG(32213))
        #
        #       if ans :
        #           login = self.login.logIN();
        #
        #           if login:u
        #               if self.last_page_url:
        #                   self.handleURLFromClick(self.last_page_url)
        #       else:
        #           return

        if 'token' in res:
            return res['token']

        return res

    def getScheduleByChannel(self, channelId, scheduleDate):
        queryStr = "?platformId=" + self.platformId \
            + '&channelId=' + channelId \
            + '&fromHour=0&toHour=24' \
            + '&scheduleDt=' + scheduleDate \
            + '&timezone=' + self.timezone
        res = self.getData(const.CHANNEL_LIST_BY_HOUR + queryStr, {})
        if 'resultCode' not in res:
            log('Result code not found in response')
            return None
        else:
            if not int(res['resultCode']) == 100:
                log('Error code returned: ' + res['resultCode'])
                log(str(res))
                return None
            else:
                if 'list' not in res:
                    log('No program list found in response')
                    return None
                else:
                    if len(res['list']) > 0:
                        return res['list'][0]
                    else:
                        log('Program list is empty!')
                        return None

    def getSchedule(self):
        queryStr = ('?platformId=' + self.platformId + '&channelId=' +
                    '&fromHour=0&toHour=1&scheduleDt=' +
                    datetime.datetime.now().strftime('%Y%m%d%H%M%S') + '&timezone=Europe/Berlin')
        res = self.getData(const.CHANNEL_LIST_BY_HOUR + queryStr, {})
        if 'resultCode' not in res:
            return None
        else:
            if not int(res['resultCode']) == 100:
                return None
            else:
                if 'list' not in res:
                    return None
                else:
                    log("Returning a list" + str(res['list']))
                    return res['list']

    def getChannelList(self):
        log('Getting Channel List-:')
        if not self.platformId:
            self.getPlatformId()
            if not self.platformId:
                log("Cannot get platform Id!")
                return None

        isActive = self.checkAccount()
        if not isActive:
            login = self.login.logIN()
            if not login:
                log('login is empty after logIN')
                return None
        res = self.getData(const.CHANNEL_LIST + "?platformId=" + self.platformId, {})

        chans = list()

        if 'resultCode' not in res:
            log('ResultCode not found in channel_list response')
            return None
        else:
            if not int(res['resultCode']) == 100:
                log('Result code is not Hundred' + res['resultCode'])
                return None
            else:
                if 'channelPackageList' in res:
                    for pkg in res['channelPackageList']:
                        log('NAME: ' + pkg['name'])
                        for chan in pkg['channelList']:
                            chans.append(chan)
        return chans

    def checkAccount(self):
        log('check if account still active')
        url = const.SITE_ACCOUNT_CHECK + '?platformId=' + self.platformId
        res = self.getData(url, [])
        if 'resultCode' in res:
            if int(res['resultCode']) == 305:
                return False

        elif 'username' in res:
            return True
        else:
            return False

    def getPlatformId(self):
        log('get platform id :')
        if self.platformId:
            return self.platformId
        else:
            res = self.getData(const.SITE_GET_PLATFORM, None)
            log(str(res))
            if 'resultCode' in res:
                if int(res['resultCode']) == 100:
                    log('got platformId' + res['code'])
                    self.platformId = res['code']
            return self.platformId


class Login:
    usr = ''
    pas = ''
    token = None

    def logIN(self):
        log("LogIN")
        log(sys.version_info)
        self.usr = const.ADDON.getSetting('username')
        self.pas = const.ADDON.getSetting('password')
        if not self.usr or not self.pas:
            const.ADDON.openSettings(const.ID)
            return
        data = self.makeUserPass()
        self.token = controller.getData(const.SITE_LOGIN_PAGE, data)
        log("Token => " + self.token)
        if self.token:
            self.writeInFile()
            return self.token
        return None

    def makeUserPass(self):
        log('username: %s' % (self.usr))
        log('password: %s' % (self.pas))
        return {
            "email": self.usr,
            "password": base64.b64encode(self.pas),
            "platformId": const.PLATFORM_ID,
            "deviceId": "W",
            "deviceType": "W",
            "authInstitude": "0",
            "accessNetworkType": "W",
            "deviceModel": "PC"
        }

    def writeInFile(self):
        fopen = open(const.TOKEN_FILEPATH, "w+")
        fopen.write(self.token + " " + const.ADDON.getSetting('username'))
        fopen.close()


controller = Controller()
controller.login = Login()

###############################################################################
#                        LIST VIEW                                           ##
###############################################################################


class List(xbmcgui.WindowXMLDialog):
    C_LIST = 6001
    C_CANCEL = 6004

    def __new__(cls):
        return super(List, cls).__new__(cls, 'script-video-mntv-tv-list.xml', const.ADDONPATH)

    def __init__(self):
        super(List, self).__init__()
        # self.swapInProgress = False

    def onInit(self):
        # control = self.getControl(self.C_LIST)
        self.updateList(controller.menu_list)
        self.setFocus(self.getControl(self.C_LIST))

    def onClick(self, controlId):
        if controlId == self.C_CANCEL:
            self.close()

        if controlId == self.C_LIST:
            list_control = self.getControl(self.C_LIST)
            item_url = list_control.getSelectedItem().getLabel2()
            show_title = list_control.getSelectedItem().getLabel()
            controller.last_sel_on_list = num(list_control.getSelectedPosition())

            if item_url == 'logout':
                controller.login.logOUT()
                self.close()
                return

            elif item_url == 'search':
                controller.search(item_url, self)
                return

            controller.handleURLFromClick(item_url, show_title, self)
            controller.removeMenu()

    def onAction(self, action):
        act_id = action.getId()

        if act_id in [const.ACTION_RIGHT, const.KEY_NAV_BACK]:
            controller.removeMenu()

    def onFocus(self, controlId):
        pass

    def updateList(self, list_items):
        self.is_menu = False

        if not list_items:
            controller.getChannelList()
            self.is_menu = True

        list_control = self.getControl(self.C_LIST)
        list_control.reset()
        try:
            list_control.addItems(list_items)
        except Exception as e:
            log(e)
            log('!!!ERROR: rendering menu')

        if controller.last_sel_on_list >= 0:
            list_control.selectItem(controller.last_sel_on_list)


###############################################################################
#                      Sliders VIEW                                          ##
###############################################################################


class Sliders(xbmcgui.WindowXML):
    C_LIST = 7001
    BP_LIST = 8001

    SCH_LIST = 7002
    C_TITLE = 7009
    T_LIST = 7101
    I_LIST = 7201
    P_LABEL = 7701
    P_TITLE = 7702
    P_LIST = 7703

    L_LABEL = 7601
    BP_LABEL = 8601

    lists = [7001, 7002, 7003]
    idx_start = 0
    idx_end = 0
    rows = 3
    last_focused = None
    last_prog_focused = None
    items = list()
    visible = list()
    schedule = None
    current_schedule = dict()
    channel_live_list = dict()
    channel_status_list = dict()
    current_schedule_channel = None

    schedule_date = None  # For TV Programm

    chan_icons = {
        'tv9hd': 'ch_9tv_145x90.png',
        'биднийцөөхөнмонголчууд': 'ch_bidnii_tsoohon_145x90.png',
        'bloombergmongoliahd': 'ch_bloomberg_145x90.png',
        'боловсролhd': 'ch_bolovsrol_145x90.png',
        'channel11hd': 'ch_c11_145x90.png',
        'c1hd': 'ch_c1_145x90.png',
        'dreamboxhd': 'ch_dreambox_145x90.png',
        'eaglenewshd': 'ch_eaglenews_145x90.png',
        'эхорон': 'ch_ehoron_145x90.png',
        'etvhd': 'ch_etv_145x90.png',
        'уихчуулган': 'ch_ihchuulgan_145x90.png',
        'mn25hd': 'ch_mn25_145x90.png',
        'mnb': 'ch_mnb_145x90.png',
        'mnb2': 'ch_mnb2_145x90.png',
        'mnba': 'ch_mnba_145x90.png',
        'mnchd': 'ch_mnc_145x90.png',
        'nbatalk': 'ch_nba_talk_145x90.png',
        'ntvhd': 'ch_ntv_145x90.png',
        'otvhd': 'ch_otv_145x90.png',
        'royalhd': 'ch_royal_145x90.png',
        'sbnhd': 'ch_sbn_145x90.png',
        'sevenhd': 'ch_seven_145x90.png',
        'startvhd': 'ch_star_145x90.png',
        'сүлдтвhd': 'ch_suld_145x90.png',
        'tv5hd': 'ch_tv5_145x90.png',
        'tv6': 'ch_tv6_145x90.png',
        'ubshd': 'ch_ubs_145x90.png',
        'vtv': 'ch_vtv_145x90.png',
    }

    def __new__(cls, data):
        return super(Sliders, cls).__new__(cls, 'script-video-mntv-tv-sliders.xml',
                                           const.ADDONPATH)

    def __init__(self, data):
        self.data = data
        super(Sliders, self).__init__()

    def onInit(self):
        startBusy()
        if not self.data:
            self.data = controller.getChannelList()
            if not self.data:
                self.close()
                return

        # if not self.schedule:
        #   self.schedule = controller.getSchedule()
        #
        #   if not self.schedule:
        #       self.close()
        #       return
        #
        #   for sch in self.schedule:
        #       self.current_schedule[sch['channelId']] = sch['schedules']

        # self.title = "Сувгаа сонгож үзнэ үү"
        # self.getControl(self.C_TITLE).setLabel('[B]'+self.title.upper()+'[/B]')

        try:
            controller.removeMenu()
        except Exception as e:
            log('!!!ERROR:F no menu' + e)

        self.updateList()
        stopBusy()

    def _isPayChannel(self, chanid):
        return self.channel_status_list.get(chanid) == 0

    def onClick(self, controlId):
        # clicked on replay list shows tv program
        if controlId in [self.BP_LIST, self.C_LIST]:
            list_control = self.getControl(controlId)
            item_id = list_control.getSelectedItem().getLabel2()
        if controlId in [self.BP_LIST]:
            log('BUTSAAH TSESEN DEER DARSAN')
            list_control = self.getControl(controlId)
            item_id = list_control.getSelectedItem().getLabel2()
            chanel_name = list_control.getSelectedItem().getLabel()
            self.current_schedule_channel = item_id
            # DO NOT PLAY, SHOW PROGRAM LIST
            controller.changeControlVisibility(self, False, self.P_LABEL)
            startBusy()
            # controller.changeControlVisibility(self, False, const.LOADER_FLAG)
            today = datetime.datetime.now()
            self.schedule_date = today
            today_str = today.strftime('%Y%m%d000000')
            today_program = controller.getScheduleByChannel(item_id, today_str)
            # log(str(today_program))
            stopBusy()
            if not today_program:
                ans = dialog.yesno('AHXAAR',
                                   'Мэдээ харуулах боломжгүй, шууд нэвтрүүлэг үзэх үү?',
                                   yeslabel='За үзье',
                                   nolabel='Буцъя')
                if ans:
                    curUrl = self.channel_live_list[self.current_schedule_channel]
                    if curUrl:
                        self.last_focused = self.getControl(self.BP_LIST)
                        controller.tvPlay(curUrl, 'Шууд дамжуулалт')
                controller.changeControlVisibility(self, True, self.P_LABEL)
            elif 'schedules' in today_program:
                self.getControl(self.C_TITLE).setLabel('[B]' + chanel_name + '[/B]')
                startBusy()
                self.updateTvProgramm(today_program['schedules'])
                stopBusy()

        # clicked on live list show live tv
        if controlId in [self.C_LIST]:
            log('LIVE CHANNEL DEER DARSAN')
            list_control = self.getControl(controlId)
            item_id = list_control.getSelectedItem().getLabel2()
            live_chan_name = list_control.getSelectedItem().getLabel()
            curUrl = self.channel_live_list[item_id]
            # NOTE: ehoron channel has different adresse!
            self.last_focused = self.getControl(self.C_LIST)
            controller.changeControlVisibility(self, True, self.P_LABEL)
            controller.tvPlay(curUrl, live_chan_name)
        # clicked on the program entry
        if controlId in [self.P_LIST]:
            log('PROGRAM DEER DARSAN')
            list_control = self.getControl(controlId)
            log(type(list_control))
            item_id = list_control.getSelectedItem().getLabel2()
            show_title = list_control.getSelectedItem().getLabel()
            log("showing" + show_title)
            log("showing" + item_id)

            if (item_id.strip() == ''):
                dialog.ok('AHXAAP', 'Ирээдүйн нэвтрүүлэг тул гарахгүй')
            elif show_title.find('*ШУУД*') > 0:
                log("CURRENT CHAN ID: " + self.current_schedule_channel)
                curUrl = self.channel_live_list[self.current_schedule_channel]
                if curUrl:
                    self.last_prog_focused = self.getControl(self.P_LIST)
                    if curUrl.find('172.17.17') > 0:
                        curUrl = 'https://cdn.looktv.mn/' + controller.getPlatformId(
                        ) + '/origin_1/channel/ehoron.smil/playlist.m3u8'
                    controller.tvPlay(curUrl, show_title)
            else:
                self.last_prog_focused = self.getControl(self.P_LIST)
                controller.tvPlay(item_id, show_title)
            # controller.tvPlay(item_id, show_title)
        # log("ViewMode " + str(addon.getSetting("viewMode")))
        # log("Login action")
        # #dialog.ok('Test test', 'Testo')
        # controller.login.logIN()
        # res = controller.getChannelList()
        # playUrl = res["channelPackageList"][0]["channelList"][0]["ip"]
        # controller.tvPlay(playUrl, "Baldan")
        # xbmc.executebuiltin('ActivateWindow(Settings)')

    def updateList(self):
        _list = self.getControl(self.C_LIST)
        _bp_list = self.getControl(self.BP_LIST)
        items = list()
        bp_items = list()

        for chan in self.data:
            for k, v in chan.iteritems():
                log('key: {0}, value: {1}'.format(k, v))
            chname = chan['name']
            chn = self.chan_icons.get(chname.replace(' ', '').lower().encode('utf-8'))
            item = xbmcgui.ListItem(label=u"{0}".format(chan['name']),
                                    label2=chan['id'],
                                    iconImage=chn)
            bp_item = xbmcgui.ListItem(label=u"{0}".format(chan['name']),
                                       label2=chan['id'],
                                       iconImage=chn)
            self.channel_live_list[chan['id']] = chan['ip']
            self.channel_status_list[chan['id']] = chan['free']
            items.append(item)
            bp_items.append(bp_item)

        _list.reset()
        _bp_list.reset()

        self.getControl(self.L_LABEL).setLabel('[B]ШУУД НЭВТРҮҮЛЭГ[/B]')
        self.getControl(self.BP_LABEL).setLabel('[B]УХРААЖ ҮЗЭХ[/B]')
        try:
            _list.addItems(items)
            _bp_list.addItems(bp_items)
        except Exception as e:
            log('!!!!!!!!!Error rendering list: ' + e)

        self.setFocus(self.getControl(self.C_LIST))
        self.last_focused = self.getControl(self.C_LIST)

    def updateTvProgramm(self, p_list):

        self.getControl(self.P_TITLE).setLabel('[B]' + self.schedule_date.strftime('%Y.%m.%d') +
                                               '[/B]')
        _list = self.getControl(self.P_LIST)
        items = list()
        for i, prog in enumerate(p_list):
            schedule_name = prog['name']
            tmp_time = prog['scheduleTime']
            schedule_time = tmp_time[0:tmp_time.rfind(':')]
            pUrl = prog['url']
            pLabel = ''
            if pUrl == '':
                pLabel = schedule_time + ' *     ' + schedule_name
            elif i + 1 < len(p_list) and p_list[i + 1]['url'] == '':
                pLabel = schedule_time + ' *ШУУД*     ' + schedule_name
            else:
                pLabel = schedule_time + '      ' + schedule_name
            item = xbmcgui.ListItem(label=u"{0}".format(pLabel), label2=prog['url'])
            items.append(item)

        _list.reset()

        try:
            _list.addItems(items)
        except Exception as e:
            log('!!!!!!!!!Error rendering list ' + e)

        self.setFocus(self.getControl(self.P_LIST))
        self.last_focused = self.getControl(self.C_LIST)

    def updateScheduleList(self, futureList):
        _clist = self.getControl(self.SCH_LIST)
        items = list()
        for p in futureList:
            item = xbmcgui.ListItem(label=u"{0}".format(p['name']))
            items.append(item)
        _clist.reset()
        try:
            _clist.addItems(items)
        except Exception as e:
            log('!!! Error rendering schedule: ' + e)

    def onAction(self, action):
        log("On Action" + str(action.getId()))
        act_id = action.getId()

        if act_id in [
                const.ACTION_PARENT_DIR, const.KEY_NAV_BACK, const.ACTION_PREVIOUS_MENU,
                const.ACTION_SHOW_FULLSCREEN
        ]:

            if not self.getControl(self.P_LABEL).isVisible():
                controller.changeControlVisibility(self, True, self.P_LABEL)
                self.getControl(self.C_TITLE).setLabel('')
                self.setFocus(self.last_focused)
            else:
                ans = dialog.yesno('MONTVBOX',
                                   'Та програмаас гарах гэж байна!',
                                   yeslabel='Гарна',
                                   nolabel='Үлдэнэ')
                if ans:
                    self.close()
                    return
        if act_id in [const.ACTION_LEFT, const.ACTION_RIGHT]:
            curr_id = self.getFocusId()

            if curr_id in [self.P_LIST]:
                startBusy()
                if act_id == const.ACTION_LEFT:
                    self.schedule_date = self.schedule_date - datetime.timedelta(days=1)
                else:
                    self.schedule_date = self.schedule_date + datetime.timedelta(days=1)
                date_str = self.schedule_date.strftime('%Y%m%d000000')
                day_program = controller.getScheduleByChannel(self.current_schedule_channel,
                                                              date_str)

                stopBusy()
                if 'schedules' in day_program:
                    self.updateTvProgramm(day_program['schedules'])

        # temp commented out
        # if act_id in [ const.ACTION_LEFT, const.ACTION_RIGHT ]:
        #   list_control    = self.getControl(self.C_LIST)
        #   show_title          = list_control.getSelectedItem().getLabel()
        #   chan_id         = list_control.getSelectedItem().getLabel2()
        #   ili = list()
        #   if not chan_id in  self.current_schedule:
        #       log('empty schedule')
        #   else:
        #       for ch in self.current_schedule[chan_id]:
        #           log('schedule: ' + ch['name'])
        #           ili.append(ch)
        #       self.updateScheduleList(ili)

    def onFocus(self, controlId):
        log("On Focus " + str(controlId))

        if not self.getControl(
                self.P_LABEL).isVisible() and controlId == self.P_LIST and self.last_prog_focused:
            self.setFocus(self.last_prog_focused)

        # elif controlId == self.C_LIST and self.last_focused:
        #   self.setFocus(self.last_focused)
        #


###############################################################################
#                    PLAYER                                                  ##
###############################################################################


class Player(xbmc.Player):
    info = None
    tracking_key = None
    is_live = None
    is_playing = False
    player_playing = "script-video-bgtime-tv-player-pause"
    player_paused = "script-video-bgtime-tv-player-play"
    gui = None
    resume = 0
    str_time = 0

    def __init__(self):
        xbmc.Player.__init__(self)

    def onIint(self):
        pass

    def onPlayBackStarted(self):
        self.checkTime(self.resume)

        # if self.tracking_key is not None:
        #   now = datetime.datetime.today()
        #   str_time = int(time.mktime(now.timetuple()))
        #   self.info = {
        #       'key'           : self.tracking_key,
        #       'stream_started': str_time,
        #       'current_time'  : num(self.getTime()),
        #   }
        #   self.reportPlaybackProgress(self.info, 'start')

    def onPlayBackResumed(self):
        pass

    def onPlayBackPaused(self):
        pass

    def is_overlay(self):
        return xbmc.getCondVisibility("VideoPlayer.UsingOverlays")

    def is_playback_paused(self):
        return bool(xbmc.getCondVisibility("Player.Paused"))

    def onPlayBackStopped(self):
        # if self.info is not None:
        #   self.reportPlaybackProgress(self.info, 'stop')

        self.is_playing = False

    def onPlayBackSeek(self, time, seekOffset):
        pass

    def stopPlayer(self):
        self.onPlayBackStopped()
        self.stop()

    def reportPlaybackProgress(self, info, action):
        token = controller.getToken()
        if info is None:
            return
        if self.tracking_key is not None:
            data = {
                'token': token,
                'key': self.tracking_key,
                'stream_started': str(num(info['stream_started'])),
                'current_time': str(num(info['current_time'])),
                'action': action
            }
            send = urllib.urlencode(data)
            request = urllib2.Request(const.SITE_PATH + 'tracking/report_playback',
                                      send,
                                      headers={
                                          "User-Agent":
                                          xbmc.getUserAgent() + " BGTimeTV Addon " +
                                          str(const.VERSION)
                                      })
            log(request)

    def checkTime(self, curr_time):
        if curr_time > 0:
            try:
                self.seekTime(curr_time)
            except Exception as e:
                log(e)

    def onAction(self, action):
        log("On Action" + str(action.getId()))
        log('neeed to stop!!!')
