#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright (C) 2018 Montvbox-Dev

import gui


def main_menu():
    data = []
    m = gui.Sliders(data)
    m.doModal()
    del m
    return


if __name__ == '__main__':
    main_menu()
