## NEWS ##
NEWS_URL           = 'https://www.montvbox.com/mbxrepo/news.json.gz'
ADDONS_URL         = 'https://www.montvbox.com/mbxrepo/addons.json.gz'
ADDONS_MD5         = 'https://www.montvbox.com/mbxrepo/addons.xml.md5'
NEWS_CHECK_TIME    = 7200 #2 Hours
UPDATES_CHECK_TIME = 3600 #1 Hour
SERVICE_BUILD_TIME = 3600 #1 Hour
