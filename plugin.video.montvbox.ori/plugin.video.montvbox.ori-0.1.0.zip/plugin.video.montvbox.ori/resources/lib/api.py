from time import time
import arrow
import json
import uuid
import math

from slyguy import userdata, settings
from slyguy.util import jwt_data
from slyguy.util import strip_namespaces, hash_6, get_system_arch
from slyguy.log import log
from slyguy.session import Session
from slyguy.exceptions import Error
from slyguy.mem_cache import cached

from .constants import HEADERS, HOST, LOGIN_PATH, ACCOUNT_PATH, HOME_PATH
from .constants import PLAYLIST_PATH, ASSET_PATH, EPISODE_PATH, STREAM_PATH
from .constants import EPG_PATH, ONNOW_PATH, PLAY_HOST, PLAYBACK_PATH
from .language import _

class APIError(Error):
    pass

class API(object):
    def new_session(self):
        self.logged_in = False
        self._session  = Session(HEADERS)
        self._set_authentication()

    def _set_authentication(self):
        token = userdata.get('access_token')
        if not token:
            return

        self._session.headers.update({'Authorization': 'Bearer {}'.format(token)})
        self.logged_in = True

    def _device_id(self):
        device_id = userdata.get('device_id')
        if device_id:
            return device_id

        device_id = settings.get('device_id')

        try:
            mac_address = uuid.getnode()
            if mac_address != uuid.getnode():
                mac_address = ''
        except:
            mac_address = ''

        system, arch = get_system_arch()
        device_id = device_id.format(username=userdata.get('username'), mac_address=mac_address, system=system).strip()

        if not device_id:
            device_id = uuid.uuid4()

        log.debug('Raw device id: {}'.format(device_id))
        #device_id = hash_6(device_id, length=16)
        #log.debug('Hashed device id: {}'.format(device_id))

        userdata.set('device_id', '{}'.format(device_id))
        return '{}'.format(device_id)

    def login(self, username, password):
        self.logout()

        data = {
            'grant_type': 'tvacms',
            'username': username,
            'password': password
        }

        param = {
            'device_type': 'web',
            'duid': self._device_id()
        }

        log.info('device_id: {}'.format(self._device_id()))
        r = self._session.post(HOST + LOGIN_PATH, params=param, json=data)
        try:
            data = r.json()
        except:
            raise APIError(_(_.LOGIN_ERROR, msg=r.status_code))

        access_token = data.get('auth_token')
        if not access_token:
            raise APIError(_(_.LOGIN_ERROR, msg=data.get('detail', '')))

        token_data = jwt_data(access_token)
        #log.info('token_data: {}'.format(json.dumps(token_data)))
        userdata.set('access_token', access_token)
        userdata.set('expires', int(data['auth_expires']) - 30)
        userdata.set('account_token', data['account_token'])

        self._session.headers.update({'Authorization': 'Bearer {}'.format(access_token)})

        r1 = self._session.get(HOST + ACCOUNT_PATH.format(data['account_token']), params=param)
        try:
            #log.info('r1 response: {}'.format(json.dumps(r1.json())))
            rdata = r1.json()
        except:
            raise APIError(_(_.LOGIN_ERROR, msg=r1.status_code))

        #log.info('rdata: {}'.format(json.dumps(rdata)))
        userdata.set('profileId', rdata['data']['id'])

        self._set_authentication()

    def main_menu(self):
        params = {
            'device_type': 'web',
            'device_layout': 'web'
        }

        return self._session.get(HOST + HOME_PATH, params=params).json()

    def epg(self, islive):
        params = {
            'device_type': 'web',
            'device_layout': 'web',
            'datetimestamp': '{}'.format(math.floor(time())),
            'page': '0',
            'limit': '999'
        }
        if islive == 'True':
            return self._session.get(HOST + ONNOW_PATH, params=params).json()

        return self._session.get(HOST + EPG_PATH, params=params).json()

    def playlist(self, pid, limit):
        params = {
            'device_type': 'web',
            'device_layout': 'web',
            'limit': limit,
            'layout_id': '347',
            'page': '1'
        }
        return self._session.get(HOST + PLAYLIST_PATH.format(pid), params=params).json()

    def asset_info(self, asset_id):
        params = {
            'device_type': 'web',
            'device_layout': 'web',
            'asset_id': asset_id
        }
        return self._session.get(HOST + ASSET_PATH.format(asset_id), params=params).json()

    def series_seasons(self, series_id, season_id):
        params = {
            'device_type': 'web',
            'device_layout': 'web',
            'layout_id': '341',
            'limit': '1000'
        }
        return self._session.get(HOST + EPISODE_PATH.format(series_id, season_id), params=params).json()

    def get_stream_url(self, asset_id, stream_id, add_playlist):
        if add_playlist == 'True':
            params = {
                'device_type': 'web',
                'device_layout': 'web',
                'playlist_id': '242'
            }
        else:
            params = {
                'device_type': 'web',
                'device_layout': 'web',
            }

        return self._session.post(HOST + STREAM_PATH.format(asset_id, stream_id), data=params).json()

    def get_video_src(self, video_url, account_id, pk):
        self._session.headers.update({'Accept': 'application/json;pk={}'.format(pk)})
        self._session.headers.update({'Host': 'edge.api.brightcove.com'})
        resp = self._session.get(PLAY_HOST + PLAYBACK_PATH.format(account_id, video_url))
        self._session.headers.update({'Host': 'beacon.playback.api.brightcove.com'})
        self._session.headers.update({'Accept': 'application/json, text/plain, */*'})
        return resp.json()

    def logout(self):
        userdata.delete('access_token')
        userdata.delete('expires')
        userdata.delete('userid')
        userdata.delete('regionid')
        userdata.delete('userid1')
        userdata.delete('uid')
        self.new_session()
