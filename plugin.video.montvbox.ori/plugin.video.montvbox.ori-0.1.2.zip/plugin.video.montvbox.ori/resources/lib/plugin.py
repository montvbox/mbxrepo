import datetime
import json
from base64 import b64encode

from kodi_six import xbmc, xbmcaddon
import arrow
from slyguy import gui, inputstream, plugin, settings, signals, userdata
from slyguy.util import get_addon
from slyguy.exceptions import PluginError

from slyguy.log import log
from .api import API
from .language import _

api = API()

@signals.on(signals.BEFORE_DISPATCH)
def before_dispatch():
    api.new_session()

    username = settings.get('username')
    if not username:
        addon = get_addon('plugin.video.montvbox.voo', install=False)
        if not addon:
            return
        username = addon.getSetting('username')
        password = addon.getSetting('password')
        settings.set('username', username)
        settings.set('password', password)

    username = settings.get('username')
    password = settings.get('password')

    api.login(username, password)
    plugin.logged_in = api.logged_in

@plugin.route('')
def home(**kwargs):
    folder = plugin.Folder()

    # data = api.main_menu()

    # menus = []
    # for row in data['data']['screen']['blocks']:
    #     for subrow in row['widgets']:
    #         pl = subrow['playlist']
    #         if pl['type'] == 'playlists':
    #             if pl['name'] == 'HOLLYWOOD':
    #                 continue
    #             if pl['id'] == 406:
    #                 continue
    #             if pl['id'] == 448:
    #                 continue
    #             menus.append({'id': pl['id'], 'name': pl['name']})

    #for menu in menus:
    #    folder.add_item(label=menu['name'], path=plugin.url_for(playlist, pid=menu['id'], name=menu['name']))

    folder.add_item(label=_.SHOW, path=plugin.url_for(playshow, name=_.SHOW, islive=False))
    folder.add_item(label=_.LIVE, path=plugin.url_for(playtv, name=_.LIVE, islive=True))
    #folder.add_item(label=_.PROGRAMM, path=plugin.url_for(playtv, name=_.PROGRAMM, islive=False))

    return folder

@plugin.route()
def playshow(name, islive, **kwargs):
    folder = plugin.Folder(name, no_items_label=_.NO_MATCHES)

    data = api.show_menu()

    menus = []
    for row in data['data']['screen']['blocks']:
        for subrow in row['widgets']:
            pl = subrow['playlist']
            if pl['type'] == 'playlists':
                menus.append({'id': pl['id'], 'name': pl['name']})

    for menu in menus:
       folder.add_item(label=menu['name'], path=plugin.url_for(playlist, pid=menu['id'], name=menu['name']))

    return folder

@plugin.route()
def playtv(name, islive, **kwargs):
    folder = plugin.Folder(name, no_items_label=_.NO_MATCHES)
    data = api.epg(islive)
    if islive != 'True':
        for tv in data['data']['blocks'][0]['widgets'][0]['playlist']['contents']:
            folder.add_item(label=tv['name'], path=plugin.url_for(tvprogramm, islive=islive, name=tv['name'], imgurl=tv['image']['url'], pid=tv['id']))
        return folder

    for tv in data['data']['blocks'][0]['widgets'][0]['playlist']['contents']:
        schedule = tv['scheduling']
        info = {}
        imgurl = tv['image']['url']
        if len(schedule) == 1:
            start = datestr(schedule[0]['start_time'])
            end = datestr(schedule[0]['end_time'])
            info = {'plot': _(_.PROGRAM_NOW_ONE, title=schedule[0]['name'], start=start, end=end)}
            item = plugin.Item(
                label=schedule[0]['name'],
                art={'thumb': imgurl},
                info=info,
                path=plugin.url_for(play_stream, asset_id=tv['id'], stream_id=tv['streams'][0]['id'], add_playlist=False),
                playable=True
            )
            folder.add_items(item)
        if len(schedule) > 1:
            start = datestr(schedule[0]['start_time'])
            end = datestr(schedule[0]['end_time'])
            start_n = datestr(schedule[1]['start_time'])
            end_n = datestr(schedule[1]['end_time'])

            info = {'plot': _(_.PROGRAM_NOW_TWO,
                              title=schedule[0]['name'], start=start, end=end,
                              title_n=schedule[1]['name'], start_n=start_n, end_n=end_n)}
            item = plugin.Item(
                label=schedule[0]['name'],
                art={'thumb': imgurl},
                info=info,
                path=plugin.url_for(play_stream, asset_id=tv['id'], stream_id=tv['streams'][0]['id'], add_playlist=False),
                playable=True
            )
            folder.add_items(item)
    return folder


def datestr(v_date):
    return arrow.get(v_date).to('local').format('H:mm')

@plugin.route()
def tvprogramm(islive, name, imgurl, pid, **kwargs):
    folder = plugin.Folder(name, no_items_label=_.NO_MATCHES)
    data = api.epg(islive)
    schedule = []
    for row in data['data']['blocks'][0]['widgets'][0]['playlist']['contents']:
        if pid == str(row['id']):
            schedule = row['scheduling']
            break

    for tt in schedule:
        start = arrow.get(tt['start_time']).to('local').format('H:mm')
        end = arrow.get(tt['end_time']).to('local').format('H:mm')
        info = {'plot': _(_.PROGRAM_PLOT, title=tt['name'], start=start, end=end)}
        item = plugin.Item(
            label=tt['name'],
            art={'thumb': imgurl},
            info=info,
            #path=plugin.url_for(playlist(pid, tt['name'])),
            playable=False
        )
        folder.add_items(item)
    return folder


@plugin.route()
def playlist(pid, name, **kwargs):
    folder = plugin.Folder(name, no_items_label=_.NO_MATCHES)

    data = api.playlist(pid, 150)
    total = data['pagination']['total_size']
    if not total:
        return

    if total > 150:
        data = api.playlist(pid, total)

    for row in data['data']:
        title = row['name']
        start = ''
        end = ''

        item = plugin.Item(
            label    = title,
            art      = {'thumb': row['image']['url']},
            path     = plugin.url_for(play_asset, asset_id=row['id'], name=title),
            playable = False,
        )

        folder.add_items(item)

    return folder

@plugin.route()
def play_asset(asset_id, name, **kwargs):
    folder = plugin.Folder(name, no_items_label=_.NO_MATCHES)
    data = api.asset_info(asset_id)
    asset = data['data']['asset']

    if asset['type'] == 'movies':
        item = plugin.Item(
            label    = asset['name'],
            art      = {'thumb': asset['images']['poster']['url']},
            path     = plugin.url_for(play_stream, asset_id=asset['id'], stream_id=asset['streams'][0]['id']),
            playable = True,
        )
        folder.add_items(item)
        return folder

    if asset['type'] == 'series':
        for row in asset['seasons']:
            item = plugin.Item(
                label    = row['name'],
                art      = {'thumb': asset['images']['poster']['url']},
                path     = plugin.url_for(play_series, series_id=asset_id, series_name=row['name'], season_id=row['id'] ),
                playable = False,
            )
            folder.add_items(item)

    return folder


@plugin.route()
def play_series(series_id, series_name, season_id, **kwargs):
    folder = plugin.Folder(series_name, no_items_label=_.NO_MATCHES)
    data = api.series_seasons(series_id, season_id)
    log.debug('Response: {}'.format(json.dumps(data)))
    for row in data['data']:
        item = plugin.Item(
            label    = row['name'],
            art      = {'thumb': row['image']['url']},
            path     = plugin.url_for(play_stream, asset_id=row['id'], stream_id=row['streams'][0]['id']),
            playable = True,
        )
        folder.add_items(item)

    return folder


@plugin.route()
def play_stream(asset_id, stream_id, add_playlist='True', **kwargs):
    data = api.get_stream_url(asset_id, stream_id, add_playlist)

    if 'data' not in  data:
        raise PluginError(_.NO_DATA_TO_PLAY)

    url = data['data']['stream']['url']
    account_id = data['data']['stream']['video_provider_details']['account_id']
    policy_key = data['data']['stream']['video_provider_details']['policy_key']

    data1 = api.get_video_src(url, account_id, policy_key)
    lic_url = ''
    video_src = ''
    for row in data1['sources']:
        if "fairplay" in row['src']:
            continue
        if row['type'] == 'application/dash+xml' and row['key_systems']['com.widevine.alpha']:
            lic_url = row['key_systems']['com.widevine.alpha']['license_url']
            video_src = row['src']
            break
        if row['type'] == 'application/x-mpegURL':
            video_src = row['src']
            lic_url = ''
            break
    if lic_url == '':
        return _playhls(video_src)
    return _play(video_src, lic_url=lic_url)


def _playhls(url):
    return plugin.Item(
        path=url,
        inputstream=inputstream.HLS(live=True)
    )


def _play(url, lic_url):
    return plugin.Item(
        path=url,
        inputstream=inputstream.Widevine(license_key=lic_url)
    )
