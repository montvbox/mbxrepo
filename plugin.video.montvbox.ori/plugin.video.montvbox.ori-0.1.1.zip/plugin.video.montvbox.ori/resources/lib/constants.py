HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Linux; U; Android 5.1; en-US; SHIELD Android TV Build/LMY47D) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/10.5.2.582 U3/0.8.0 Mobile Safari/534.30',
    'origin': 'https://ori.mn',
    'referer': 'https://ori.mn',
    'Host': 'beacon.playback.api.brightcove.com',
    'Accept': 'application/json, text/plain, */*',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'mn',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'cross-site',
    'DNT': '1',
    'TE': 'trailers'
}

HOST = 'https://beacon.playback.api.brightcove.com'
LOGIN_PATH = '/mongoltv/api/account/login'
ACCOUNT_PATH = '/mongoltv/api/account/{}'
PROFILE_PATH = '/mongoltv/api/account/{}/profiles'
HOME_PATH = '/mongoltv/api/menus/0/option/13916-home'
PLAYLIST_PATH = '/mongoltv/api/playlists/{}/assets'
ASSET_PATH = '/mongoltv/api/assets/{}'
EPISODE_PATH = '/mongoltv/api/tvshow/{}/season/{}/episodes'
STREAM_PATH = '/mongoltv/api/assets/{}/streams/{}'
EPG_PATH = '/mongoltv/api/epg'
ONNOW_PATH = '/mongoltv/api/onnow'

PLAY_HOST = 'https://edge.api.brightcove.com'
PLAYBACK_PATH = '/playback/v1/accounts/{}/videos/{}'

DEV_TYPE = 'androidtv'
SERVICE_TIME = 300
