import uuid
import json

from slyguy import userdata, settings
from slyguy.util import get_system_arch
from slyguy.log import log
from slyguy.session import Session
from slyguy.exceptions import Error

from .constants import HOST_URL, VERSION, HEADERS, DEV_TYPE
from .language import _


class APIError(Error):
    pass


class API(object):
    def new_session(self):
        self.logged_in = False
        self._session = Session(HEADERS)
        self._set_authentication()

    def _set_authentication(self):
        token = userdata.get('access_token')
        if not token:
            return

        self._session.headers.update({'x-token': token})
        userdata.set('access_token', token)
        self.logged_in = True

    def _device_id(self):
        device_id = userdata.get('device_id')
        if device_id:
            return device_id

        device_id = settings.get('device_id')

        try:
            mac_address = uuid.getnode()
            if mac_address != uuid.getnode():
                mac_address = ''
        except:
            mac_address = ''

        system, arch = get_system_arch()
        device_id = device_id.format(username=userdata.get('username'), mac_address=mac_address, system=system).strip()

        if not device_id:
            device_id = uuid.uuid4()

        userdata.set('device_id', '{}'.format(device_id))
        return '{}'.format(device_id)

    def login(self, username, password):
        self.logout()

        data = {
            'username': username,
            'password': password,
            'version': VERSION,
            'mac': self._device_id()
        }

        self._session.headers.update({'referer': 'https://www.voo.mn'})
        self._session.headers.update({'origin': 'https://www.voo.mn'})
        self._session.headers.update({'x-devicemodel': 'Chrome95.0.4638.69'})
        self._session.headers.update({'x-devicetype': DEV_TYPE})
        self._session.headers.update({'x-languagecode': 'mn_MN'})
        self._session.headers.update({'x-mac': self._device_id()})
        self._session.headers.update({'x-version': VERSION})
        self._session.headers.update({'Sec-Fetch-Dest' : 'empty'})
        self._session.headers.update({'Sec-Fetch-Mode' : 'cors'})
        self._session.headers.update({'Sec-Fetch-Site' : 'same-site'})
        self._session.headers.update({'sec-ch-ua-mobile' : '?0'})
        self._session.headers.update({'sec-ch-ua-platform' : 'Linux'})
        self._session.headers.update({'sec-ch-ua' : '"Chromium";v="92", " Not A;Brand";v="99", "Google Chrome";v="92"' })
        self._session.headers.update({'user-agent' : 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36' })

        log.info('headers: {}'.format(self._session.headers))
        r = self._session.post(HOST_URL + '/v1/auth/login', json=data)
        log.info('login response: {}'.format(json.dumps(r.json())))
        try:
            data = r.json()
        except:
            raise APIError(_(_.LOGIN_ERROR, msg=r.status_code))

        access_token = data.get('token')
        if not access_token:
            raise APIError(_(_.LOGIN_ERROR, msg=data.get('detail', '')))

        self._session.headers.update({'x-token': access_token})

        #log.info('response: {}'.format(json.dumps(data)))
        userdata.set('access_token', access_token)

        info_data = {
            'mac': self._device_id()
        }
        r1 = self._session.post(HOST_URL + '/v1/sys/info', json=info_data)
        try:
            #log.info('r1 response: {}'.format(json.dumps(r1.json())))
            rdata = r1.json()
        except:
            raise APIError(_(_.LOGIN_ERROR, msg=r1.status_code))

        self._set_authentication()

    def kinos(self, catId, pageSize=30):
        params = {
            'mac': self._device_id(),
            'categoryIds': catId,
            'labelIds': '',
            'page': 0,
            'pageSize': pageSize
        }

        return self._session.post(HOST_URL + '/v1/filter/content', json=params).json()

    def categories(self, catId):
        params = {
            'mac': self._device_id(),
            'categoryId': catId,
            'mediaType': 'vod'
        }

        return self._session.post(HOST_URL + '/v1/content/category', json=params).json()

    def content_detail(self, contentId):
        params = {
            'contentId': contentId,
        }

        return self._session.post(HOST_URL + '/v1/content/detail', json=params).json()

    def tv_detail(self, contentId):
        params = {
            'contentId': contentId
        }
        return self._session.post(HOST_URL + '/v1/channel/detail', json=params).json()

    def content_auth(self, contentId, playType='', contentType='vod'):
        params = {
            'contentId': contentId,
            'mac': self._device_id(),
            'playType': playType,
            'type': contentType
        }
        resp = self._session.post(HOST_URL + '/v1/play/auth', json=params).json()
        log.info('auth response: {}'.format(json.dumps(resp)))
        return resp

    def tv_list(self):
        params = {
            'categoryId': '',
            'mac': self._device_id(),
            'page': 0,
            'pageSize': 60
        }

        return self._session.post(HOST_URL + '/v1/channel/list', json=params).json()

    def tv_schedule(self, channelId, timeOffset):
        params = {
            'channelId': channelId,
            'mac': self._device_id(),
            'scheduleType': '0',
            'timeOffset': timeOffset
        }

        return self._session.post(HOST_URL + '/v1/channel/schedules', json=params).json()

    def logout(self):
        userdata.delete('access_token')
        userdata.delete('device_id')
        self.new_session()
