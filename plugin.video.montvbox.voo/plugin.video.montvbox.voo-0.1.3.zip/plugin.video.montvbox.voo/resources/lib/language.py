from slyguy.language import BaseLanguage

class Language(BaseLanguage):
    ASK_USERNAME     = 30001
    ASK_PASSWORD     = 30002
    LOGIN_ERROR      = 30003
    PLAYBACK_ERROR   = 30004
    KINO             = 30005
    VIDEO            = 30006
    CHILD            = 30007
    TB               = 30008
    KINO_G1          = 30009
    KINO_G2          = 30010
    KINO_G3          = 30011
    NOGOODOR         = 30012
    NO_MATCHES       = 30013
    DAY_FORMAT       = 30014

    MATCH_PLOT       = 30014
    PROGRAM_PLOT     = 30015

    CONTENT_ERROR    = 30016
    NO_CONTENT_ERROR = 30017
    LIVE             = 30018

    SUBSCRIBE_ERROR  = 30020
    NO_VIDEOS        = 30021

    FUTURE_PROGRAM   = 30022

    ONOODOR          = 30023
    ONOODOR1         = 30024
    ONOODOR2         = 30025
    ONOODOR3         = 30026

    CONTENT_PLOT = 30027

_ = Language()
