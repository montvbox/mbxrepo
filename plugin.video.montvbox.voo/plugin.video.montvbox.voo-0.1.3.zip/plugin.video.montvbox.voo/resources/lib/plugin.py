
from kodi_six import xbmc, xbmcaddon
import arrow
from slyguy import gui, inputstream, plugin, settings, signals, userdata
from slyguy.util import get_addon

from .api import API
from .language import _
from slyguy.exceptions import PluginError

api = API()


@signals.on(signals.BEFORE_DISPATCH)
def before_dispatch():
    api.new_session()

    username = settings.get('username')
    if not username:
        addon = get_addon('plugin.video.montvbox.looktv', install=False)
        if not addon:
            return
        username = addon.getSetting('username')
        password = addon.getSetting('password')
        settings.set('username', username)
        settings.set('password', password)

    username = settings.get('username')
    password = settings.get('password')
    settings.setBool('verify_ssl', False)

    api.login(username, password)
    plugin.logged_in = api.logged_in


@plugin.route('')
def home(**kwargs):
    folder = plugin.Folder()

    folder.add_item(label=_(_.KINO, _bold=True), path=plugin.url_for(kino))
    folder.add_item(label=_(_.VIDEO, _bold=True), path=plugin.url_for(video))
    folder.add_item(label=_(_.CHILD, _bold=True), path=plugin.url_for(child))
    folder.add_item(label=_(_.TB, _bold=True), path=plugin.url_for(tv))

    return folder


@plugin.route()
def kino(**kwargs):
    folder = plugin.Folder(_.KINO, no_items_label=_.NO_MATCHES)

    folder.add_item(label=_(_.KINO_G1, _bold=True), path=plugin.url_for(media_content, label=_.KINO_G1, catId='449'))
    folder.add_item(label=_(_.KINO_G2, _bold=True), path=plugin.url_for(media_content, label=_.KINO_G2, catId='219'))
    folder.add_item(label=_(_.KINO_G3, _bold=True), path=plugin.url_for(media_content, label=_.KINO_G3, catId='614'))
    return folder


@plugin.route()
def video(**kwargs):
    folder = plugin.Folder(_.VIDEO, no_items_label=_.NO_MATCHES)

    data = api.categories('460')
    for row in data['categorys']:
        item = plugin.Item(
            label = row['categoryName'],
            path = plugin.url_for(media_content, label=row['categoryName'], catId=row['categoryId'])
        )
        folder.add_items(item)

    return folder


@plugin.route()
def child(**kwargs):
    folder = plugin.Folder(_.VIDEO, no_items_label=_.NO_MATCHES)

    data = api.categories('217')
    for row in data['categorys']:
        item = plugin.Item(
            label = row['categoryName'],
            path = plugin.url_for(media_content, label=row['categoryName'], catId=row['categoryId'])
        )
        folder.add_items(item)

    return folder


@plugin.route()
def tv(**kwargs):
    folder = plugin.Folder(_.TB, no_items_label=_.NO_MATCHES)

    data = api.tv_list()
    for row in data['channels']:
        item = plugin.Item(
            label=row['channelName'],
            art={'thumb': row['poster']},
            path=plugin.url_for(tv_detail, name=row['channelName'], contentId=row['scheduleId']))
        folder.add_items(item)

    return folder


@plugin.route()
def media_content(label, catId, **kwargs):
    folder = plugin.Folder(label, no_items_label=_.NO_MATCHES)

    data = api.kinos(catId, pageSize=30)

    if len(data['contents']) == 0:
        raise PluginError(_.NO_CONTENT_ERROR)

    if data['totalCount'] > 30:
        data = api.kinos(catId, pageSize=data['totalCount'])

    for row in data['contents']:
        title = row['name']
        kino_path = ''
        if row['templateModel'] == 'TVSERIES':
            kino_path = plugin.url_for(detail_content, name=row['name'], contentId=row['contentId'], isSerial='True' )
        else:
            kino_path = plugin.url_for(detail_content, name=row['name'],  contentId=row['contentId'], isSerial='False' )
        item = plugin.Item(
            label    = row['name'],
            art      = {'thumb': row['vPosterTV']},
            path     = kino_path,
            playable = False,
        )

        folder.add_items(item)

    return folder


@plugin.route()
def detail_content(name, contentId, isSerial, **kwargs):
    folder = plugin.Folder(name, no_items_label=_.NO_MATCHES)

    data = api.content_detail(contentId)
    ci = data.get('contentInfo', {})
    director = ci.get('director', '')
    actor = ci.get('actor', '')
    description = ci.get('description', '')
    duration = ci.get('duration', '')
    onlineyear = ci.get('onlineyear', '')
    info = {'plot': _(_.CONTENT_PLOT, director=director, actor=actor, year=onlineyear, description=description)}

    if isSerial == 'True':
        for row in data['contentInfo']['episodes']:
            item = plugin.Item(
                label=row['name'],
                art={'thumb': row['vPoster']},
                info = info,
                path=plugin.url_for(play_content, contentId=row['contentId']),
                playable=True,
            )
            folder.add_items(item)
    else:
        item = plugin.Item(
            label=name,
            art={'thumb': data['contentInfo']['vPosterTV']},
            info=info,
            path=plugin.url_for(play_content, contentId=data['contentInfo']['contentId']),
            playable=True)

        folder.add_items(item)

    return folder


@plugin.route()
def tv_detail(name, contentId, **kwargs):
    folder = plugin.Folder(name, no_items_label=_.NO_MATCHES)

    data = api.tv_detail(contentId)
    item = plugin.Item(
        label=name + ' ' + _.LIVE,
        art={'thumb': data['channel']['logo']},
        path=plugin.url_for(play_content, contentId=data['channel']['scheduleId'], playType='', contentType='live'),
        playable=True)

    folder.add_items(item)
    logo_path = data['channel']['logo']

    item_onoodor = plugin.Item(
        label=_.ONOODOR,
        art={'thumb': logo_path},
        path=plugin.url_for(tv_schedule, name=_.ONOODOR, contentId=contentId, offset=0, logo=logo_path),
        playable=False)
    item_onoodor1 = plugin.Item(
        label=_.ONOODOR1,
        art={'thumb': logo_path},
        path=plugin.url_for(tv_schedule, name=_.ONOODOR1, contentId=contentId, offset=-1, logo=logo_path),
        playable=False)
    item_onoodor2 = plugin.Item(
        label=_.ONOODOR2,
        art={'thumb': logo_path},
        path=plugin.url_for(tv_schedule, name=_.ONOODOR2, contentId=contentId, offset=-2, logo=logo_path),
        playable=False)
    item_onoodor3 = plugin.Item(
        label=_.ONOODOR3,
        art={'thumb': logo_path},
        path=plugin.url_for(tv_schedule, name=_.ONOODOR3, contentId=contentId, offset=-3, logo=logo_path),
        playable=False)

    folder.add_items(item_onoodor)
    folder.add_items(item_onoodor1)
    folder.add_items(item_onoodor2)
    folder.add_items(item_onoodor3)
    return folder


@plugin.route()
def tv_schedule(name, contentId, offset, logo, **kwargs):
    folder = plugin.Folder(name, no_items_label=_.NO_MATCHES)

    data = api.tv_schedule(contentId, offset)

    if len(data['schedules']) == 0:
        raise PluginError(_.CONTENT_ERROR)

    for row in data['schedules']:
        title=row['scheduleName'],
        start = row['startTime']
        end = row['endTime']
        info = {'plot': _(_.PROGRAM_PLOT, title=title, start=start, end=end)}
        item = plugin.Item(
            label=row['scheduleName'],
            art={'thumb': logo},
            info=info,
            path=plugin.url_for(play_content, contentId=row['scheduleId'], playType='catchup', contentType='live'),
            playable=True
        )
        folder.add_items(item)

    return folder


@plugin.route()
def play_content(contentId, playType='', contentType='vod', **kwargs):

    data = api.content_auth(contentId, playType, contentType)
    if data['resultCode'] == -1:
        raise PluginError(data['description'])

    lic_url = None
    if 'drmAuthUrl' in data.keys():
        lic_url = data['drmAuthUrl']

    play_url = data['playUrlList'][0]['playUrl']
    if play_url == 'lock':
        raise PluginError(_.NO_CONTENT_ERROR)

    return _play_content(lic_url, play_url)


def _play_content(lic_url, url):
    return plugin.Item(
        path=url,
        inputstream=inputstream.Widevine(license_key=lic_url)
    )
