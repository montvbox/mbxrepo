HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Linux; U; Android 5.1; en-US; SHIELD Android TV Build/LMY47D) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/10.5.2.582 U3/0.8.0 Mobile Safari/534.30',
    'authority': 'login.voo.mn',
    'scheme': 'https',
    'origin': 'https://www.voo.mn',
    'Accept-Encoding': 'gzip, deflate, br',
    'accept-language': 'en-US,en;q=0.9'
}

#DEV_TYPE           = 'androidtv'
DEV_TYPE           = 'pc'
SERVICE_TIME       = 300

VERSION = '1.1.2'
HOST_URL = 'https://login.voo.mn'
